<h1>:computer: Buildout template</h1>
This is the template for the IDS buildouts. Please let the digi desk know if you notice any issues/missing styles that should be added.

<h2>Instructions:</h2>
<ul>
  <li>Check the <a href="https://www.notion.so/Buildout-Documentation-4e36a30949d149e5bb074a753a88a910">Documentation</a> for the source code of our default story elements</li>
  <li>Only change styles.css, don't mess with ids.css or normalize.css</li>
</ul>
<em>More specific instructions listed on <a href="https://www.notion.so/invite/17d2acf01007e49087f6ed4138c3f874fd9d3cca">our documentation</a>!.</em>

<h2>About this project</h2>
<p>Add any useful info about your code here!</p>

